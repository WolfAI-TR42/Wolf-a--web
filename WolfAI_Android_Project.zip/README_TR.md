# Wolf AI Android proje taslağı

Bu, gönderilen `wolf_ai_V7_0.py` projesi için oluşturulmuş Android Studio / WebView arayüz prototipidir.

## APK oluşturma
1. Android Studio kurun (Android SDK 35 ve JDK 17 önerilir).
2. Bu klasörü Android Studio ile `Open` seçerek açın.
3. Gradle senkronizasyonunu tamamlayın.
4. `Build > Build Bundle(s) / APK(s) > Build APK(s)` seçin.
5. APK genellikle `app/build/outputs/apk/debug/app-debug.apk` altında oluşur.

## Şu anki kapsam
- Telefon ekranına uyumlu Wolf AI koyu/mavi arayüzü
- Mesaj arayüzü ve cihazda sohbet geçmişi
- Web arama sayfasına bağlantı
- Pollinations görsel servisi üzerinden görsel üretmeyi deneme
- Sohbet / keşfet / görsel / araçlar gezinmesi

## Önemli sınırlamalar
Bu paket henüz derlenmiş APK değildir. Çalışma ortamında Android SDK ve Gradle bulunmadığından APK burada üretilemedi. Ayrıca kaynak Python dosyasındaki tüm özellikler (hesap sistemi, geliştirici paneli, görev/not/günlük yönetimi, tam AI sohbeti ve kaynakları ayrıştıran web araştırması) Android'e birebir taşınmış değildir. Sohbet yanıtı şimdilik yerel demo modundadır; gerçek yapay zekâ için API anahtarını APK içine koymak yerine güvenli bir sunucu ara katmanı bağlanmalıdır.
